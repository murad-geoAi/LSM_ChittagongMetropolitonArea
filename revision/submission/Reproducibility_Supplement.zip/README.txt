Reproducibility supplement

From this extracted folder run:
python revision/run_revision_analysis.py
python revision/run_revision_checks.py
python revision/style_cached_figures.py

The scripts never call the archived pipeline main() or its cleanup functions. The source table encoding is preserved for transparent numerical reproduction. The repeated-CV summary is reused; holdout and spatial models are refitted. New spatial maps show observed locations, not complete predictor-raster inference. The source metadata and categorical-code limitations described in the manuscript remain.
